Version 1.7.1
=============

The library has been tested using Agda 2.6.2.

* The only change over v1.7 is that the library's Cabal file is now compatible with GHC 9.2.
